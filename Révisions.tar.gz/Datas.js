/**
 * Crée une nouvelle session de révisions
 * exoCount Nombre d'exercices
 * checked  Si cette session a été faite
 */
var Session = function (exoCount, checked) {
    return {
            exoCount : exoCount,
            checked : checked,
            toggle : function () {
                this.checked = !this.checked;
            }
        };
}

/**
 * Crée un nouveau chapitre à réviser
 * name     Nom du chaptitres
 * exoCount Nombre d'exercices à faire
 */
var Chapter = function (name, exoCount, makeSessions) {
    this.name = name;
    this.exoCount = exoCount;
    this.sessions = new Array();
    
    var remainingPages = exoCount;
    var i = 0;
    
    var sessionNbExxpectation = Math.ceil(exoCount / studyDatas.limit);
    var step = Math.min(Math.ceil (exoCount / sessionNbExxpectation), studyDatas.limit + studyDatas.tolerance);
    
    while(makeSessions && remainingPages > 0) {
        var sessionExoCount = step;
        if(remainingPages < 2 * step) {
            if(remainingPages <= studyDatas.limit + studyDatas.tolerance) {
                sessionExoCount = remainingPages;
            }
        }
        this.sessions.push(new Session(sessionExoCount, false));
        remainingPages -= sessionExoCount;
        i++;
    }
    
    this.isChecked = function() {
        for(var session in this.sessions) {
            if(!session.checked) {
                return false;
            }
        }
        
        return true;
    }
    
    this.toString = function() {
        var str = name;
        str += " ("
        for(var i in this.sessions) {
            str += this.sessions[i].exoCount + " [" + this.sessions[i].checked ? "x" : " " + "]+\n";
        }
        str += ")";
        return str;
    }
}

/**
 * Crée une nouvelle matière à réviser
 * chapterList  Tableau des chaptitres à réviser
 * date         Date de l'examen
 */
var Subject = function (name, date) {
    this.name = name;
    this.chapters = {};
    this.exam = date;

    this.toString = function () {
        var str = name + " (" + date.toString() + ")";
        for(var i in this.chapters) {
            if(i == 0) {
                str += "Chapitres :\n";
            }
            str += this.chapters[i] + "\n";
        }
        return str;
    }
    
    this.sessionsCount = function () {
        var n = 0;
        for(var chapterName in this.chapters) {
            n += this.chapters[chapterName].sessions.length;
        }
        
        return n;
    }
    
    this.checkedCount = function () {
        var n = 0;
        for(var chapterName in this.chapters) {
            var chapter = this.chapters[chapterName];
            for(var sessionIndex in chapter.sessions) {
                n += chapter.sessions[sessionIndex].checked ? 1 : 0;
            }
        }
        
        return n;
    }
}

/**
 * Crée un nouveau planning de révisions
 */
var StudyDatas = function () {
    return {
        subjects : {},
        limit : 10,
        tolerance:5,
        save : function () {
            document.cookie = JSON.stringify(this);
        },
        toString : function () {
            return this.subjects.toString();
        }
    };
}