var studyDatas = null;

openStudyDatas();

if(studyDatas == null) {
    studyDatas = new StudyDatas();
}

makePage();