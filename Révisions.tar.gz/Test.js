var maths = {
    name : "Maths",
    chapters : [
        {name : "Espaces euclidiens",
         exoCount : "40"},
        {name : "Intégrales de Riemann",
         exoCount : "20"},
    ]
};

document.cookie.subjects.maths = maths;
document.cookie.limit = 10;
